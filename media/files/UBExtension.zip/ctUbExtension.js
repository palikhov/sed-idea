/**
 * Content script for communication between background page and web page
 * for each clientID keep one connected port {chrome.runtime.connect} to background page
 * @author xmax, pavel.mash
 */
/*global document, chrome, CustomEvent, console */
(function () {
    var
        /** @type {Object.<string, Port>} */
        backgroundPorts = {},// collection of connection to background script. key = port.name
        messageObj = document.getElementById('ubExtensionPageMessageObj'); // dom element to communicate with page script
    if (!messageObj) {
        return; // no element to communicate with
    }
    /**
     * Send data to web page using UBExtensionMessage custom event
     * @param {Object} message
     */
    function sendToWebPage(message) {
        messageObj.dispatchEvent(new CustomEvent('UBExtensionMsg', {detail: message}));
    }

    function doOnBackgroundPortDisconnect(pport){
        sendToWebPage({ clientID: pport.name, messageID: pport.disconnectMsgID || -1, msgType: 'disconnected', data: 'Background port connection closed'});
        delete backgroundPorts[pport.name];
    }

    function createBackgroundPort(clientID) {
        var backgroundPort = chrome.runtime.connect({name: clientID});
        backgroundPort.onMessage.addListener(function (msg) {
            sendToWebPage(msg);
        });
        backgroundPort.onDisconnect.addListener(doOnBackgroundPortDisconnect);
        backgroundPorts[backgroundPort.name] = backgroundPort;
        return backgroundPort;
    }

    // receive events from web page. either pass it to contentScriptPort on answer immediately if we can
    messageObj.addEventListener('UBPageMsg', function (e) {
        var msg, clientID, method, messageID, bgPort;
        msg = e.detail;
        if (!msg || !msg.hasOwnProperty('method') || !msg.hasOwnProperty('clientID') || !msg.hasOwnProperty('messageID')) { // protocol error
            console.error('Invalid message format for UBPageMsg event:' + msg);
            return;
        }
        method = msg.method;
        clientID = msg.clientID;
        messageID = msg.messageID;

        try {
            switch (method) {
                case '__extensionVersion':
                    sendToWebPage({clientID: clientID, messageID: messageID, msgType: 'resolve', data: chrome.runtime.getManifest().version});
                    break;
                case '__connect':
                    bgPort = createBackgroundPort(clientID);
                    bgPort.postMessage(msg);
                    break;
                case '__disconnect':
                    bgPort = backgroundPorts[clientID];
                    if (bgPort) {
                        bgPort.disconnectMsgID = messageID;
                        bgPort.disconnect(); // port.onDisconnect fired and send response to web page
                        doOnBackgroundPortDisconnect(bgPort);
                    }
                    break;
                default: // proxy message to Background
                    backgroundPorts[clientID].postMessage(msg);
                    break;
            }
        } catch(err){
            sendToWebPage({clientID: clientID, messageID: messageID, msgType: 'reject', data: err.message});
        }
    }, false);
    messageObj.setAttribute('data-extensionAttached', 'YES');
}());

