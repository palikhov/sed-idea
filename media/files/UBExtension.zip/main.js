/**
 * background script for communicate between host application and content script
 * for each connect {chrome.runtime.connect} with content script keep one connect {chrome.runtime.connectNative} to host application
 * @class UBExtension
 *
 * @authors xmax, pavel.mash
 */
/*global chrome */
/**
 *
 * @param {Port} port
 * @constructor
 */
function UBExtension(port) {
    var me = this, pagePort = port, /**
         * Port to Native Messages Host Application
         * @type {Port}
         */
        nativePort = null;

    me.id = port.sender.tab.id + '_' + port.name;

    function onNativeMessage(msg) {
        pagePort.postMessage(msg);  // simple proxy
    }

    function onNativeDisconnect(port) {
        nativePort = null;
        if (pagePort) { // if web page close connection then  pagePort is null here
            if (((new Date()).getTime() - me.nmConnectTime) < 400) { // connection to host app fail
                pagePort.postMessage({clientID: port.name, messageID: -1, msgType: 'reject', data: 'Wrong registry setting or manifest for application with id: ' + me.hostAppName});
            }
            pagePort.disconnect();
            pagePort = null;
            UBExtension.removeInstance(me);
        }
    }

    function onPageMessage(message) {
        var method;
        if (!message) {
            return; //?
        }
        try {
            method = message.method;
            switch (method) {
                case '__connect': // 'UBConnectPluginID':
                    if (nativePort) {
                        pagePort.postMessage({clientID: message.clientID, messageID: message.messageID, msgType: 'reject', data: 'Already connected'});
                    } else if (!message.hasOwnProperty('params') || !message.params.hasOwnProperty('hostAppName')) {
                        pagePort.postMessage({clientID: message.clientID, messageID: message.messageID, msgType: 'reject', data: 'Invalid parameters for __connect'});
                    } else {
                        me.hostAppName = message.params.hostAppName;
                        me.nmConnectTime = (new Date()).getTime();
                        nativePort = chrome.runtime.connectNative(me.hostAppName);
                        nativePort.onMessage.addListener(onNativeMessage);
                        nativePort.onDisconnect.addListener(onNativeDisconnect);
                        // Verify connection to native using getVersion
                        nativePort.postMessage({clientID: message.clientID, messageID: message.messageID, method: 'getVersion', params: null});
                    }
                    break;
                default:
                    if (nativePort) {
                        nativePort.postMessage(message);
                    } else {
                        pagePort.postMessage({clientID: message.clientID, messageID: message.messageID, msgType: 'reject', data: 'Not connected'});
                    }
                    break;
            }
        } catch (err) {
            pagePort.postMessage({clientID: message.clientID, messageID: message.messageID, msgType: 'reject', data: err.message});
        }
    }

    function onPageDisconnect() {
        pagePort = null;
        if (nativePort) {
            nativePort.disconnect();
            nativePort = null;
        }
        UBExtension.removeInstance(me);
    }

    /**
     * Port to content page for exchange with web page
     */
    pagePort.onMessage.addListener(onPageMessage);
    pagePort.onDisconnect.addListener(onPageDisconnect);
}


UBExtension.instances = {};
/**
 * @param {Port} port
 */
UBExtension.newInstance = function (port) {
    var instance = new UBExtension(port);
    UBExtension.instances[instance.id] = instance;
};

UBExtension.removeInstance = function (instance) {
    delete UBExtension.instances[instance.id];
};

/**
 * if connection name start with `UBPlugin` - create new UBExtension instance.
 */
chrome.runtime.onConnect.addListener(function (port) {
    if (port.name && port.name.indexOf("UBPlugin") === 0) {
        UBExtension.newInstance(port);
    }
});